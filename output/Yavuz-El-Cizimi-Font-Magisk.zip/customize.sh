ui_print "****************************************"
ui_print "    Yavuz El Cizimi Font Modulu (v2)    "
ui_print "****************************************"
ui_print "- Sistem fontlari yukleniyor (AOSP / Samsung / Xiaomi)..."
set_perm_recursive $MODPATH 0 0 0755 0644
ui_print "- Kurulum basarili! Lutfen telefonu yeniden baslatin."
